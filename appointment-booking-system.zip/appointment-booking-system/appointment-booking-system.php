/**
 * Plugin Name: Appointment Booking System
 * Plugin URI: https://github.com/yourusername/wp-appointment-booking
 * Description: A comprehensive appointment booking system for WordPress
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: appointment-booking-system
 */

<?php
/**
 * Plugin Name: Appointment Booking System
 * Plugin URI: https://yourwebsite.com/appointment-booking-system
 * Description: A comprehensive appointment booking system for WordPress with admin management and frontend booking.
 * Version: 1.0.0
 * Author: Your Name
 * License: GPL v2 or later
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class AppointmentBookingSystem {
    
    private $table_name;
    private $services_table;
    
    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'appointments';
        $this->services_table = $wpdb->prefix . 'appointment_services';
        
        add_action('init', array($this, 'init'));
        register_activation_hook(__FILE__, array($this, 'create_tables'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    public function init() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_menu', array($this, 'admin_menu'));
        add_shortcode('appointment_booking', array($this, 'booking_form_shortcode'));
        add_action('wp_ajax_book_appointment', array($this, 'handle_booking'));
        add_action('wp_ajax_nopriv_book_appointment', array($this, 'handle_booking'));
        add_action('wp_ajax_get_available_slots', array($this, 'get_available_slots'));
        add_action('wp_ajax_nopriv_get_available_slots', array($this, 'get_available_slots'));
    }
    
    public function enqueue_scripts() {
        wp_enqueue_script('jquery');
        wp_enqueue_script('jquery-ui-datepicker');
        wp_enqueue_style('jquery-ui-css', 'https://code.jquery.com/ui/1.12.1/themes/ui-lightness/jquery-ui.css');
        
        wp_enqueue_script('appointment-booking', plugin_dir_url(__FILE__) . 'appointment-booking.js', array('jquery'), '1.0.0', true);
        wp_enqueue_style('appointment-booking', plugin_dir_url(__FILE__) . 'appointment-booking.css', array(), '1.0.0');
        
        wp_localize_script('appointment-booking', 'appointment_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('appointment_nonce')
        ));
    }
    
    public function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Appointments table
        $sql_appointments = "CREATE TABLE $this->table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(100) NOT NULL,
            email varchar(100) NOT NULL,
            phone varchar(20) NOT NULL,
            service_id mediumint(9) NOT NULL,
            appointment_date date NOT NULL,
            appointment_time time NOT NULL,
            status varchar(20) DEFAULT 'pending',
            notes text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        // Services table
        $sql_services = "CREATE TABLE $this->services_table (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(100) NOT NULL,
            duration int NOT NULL DEFAULT 60,
            price decimal(10,2) DEFAULT 0.00,
            description text,
            is_active tinyint(1) DEFAULT 1,
            PRIMARY KEY (id)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_appointments);
        dbDelta($sql_services);
        
        // Insert default services
        $this->insert_default_services();
    }
    
    private function insert_default_services() {
        global $wpdb;
        
        $default_services = array(
            array('name' => 'General Consultation', 'duration' => 30, 'price' => 50.00, 'description' => 'General consultation appointment'),
            array('name' => 'Follow-up Appointment', 'duration' => 15, 'price' => 25.00, 'description' => 'Follow-up consultation'),
            array('name' => 'Extended Consultation', 'duration' => 60, 'price' => 100.00, 'description' => 'Extended consultation appointment')
        );
        
        foreach ($default_services as $service) {
            $wpdb->insert($this->services_table, $service);
        }
    }
    
    public function admin_menu() {
        add_menu_page(
            'Appointments',
            'Appointments',
            'manage_options',
            'appointment-bookings',
            array($this, 'admin_page'),
            'dashicons-calendar-alt',
            30
        );
        
        add_submenu_page(
            'appointment-bookings',
            'All Appointments',
            'All Appointments',
            'manage_options',
            'appointment-bookings',
            array($this, 'admin_page')
        );
        
        add_submenu_page(
            'appointment-bookings',
            'Services',
            'Services',
            'manage_options',
            'appointment-services',
            array($this, 'services_page')
        );
    }
    
    public function admin_page() {
        global $wpdb;
        
        // Handle status updates
        if (isset($_POST['update_status']) && isset($_POST['appointment_id'])) {
            $wpdb->update(
                $this->table_name,
                array('status' => sanitize_text_field($_POST['status'])),
                array('id' => intval($_POST['appointment_id']))
            );
            echo '<div class="notice notice-success"><p>Appointment status updated!</p></div>';
        }
        
        // Handle deletions
        if (isset($_GET['delete']) && isset($_GET['_wpnonce'])) {
            if (wp_verify_nonce($_GET['_wpnonce'], 'delete_appointment')) {
                $wpdb->delete($this->table_name, array('id' => intval($_GET['delete'])));
                echo '<div class="notice notice-success"><p>Appointment deleted!</p></div>';
            }
        }
        
        $appointments = $wpdb->get_results("
            SELECT a.*, s.name as service_name, s.price 
            FROM $this->table_name a 
            LEFT JOIN $this->services_table s ON a.service_id = s.id 
            ORDER BY a.appointment_date DESC, a.appointment_time DESC
        ");
        
        ?>
        <div class="wrap">
            <h1>Appointment Bookings</h1>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Service</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($appointments as $appointment): ?>
                    <tr>
                        <td><?php echo esc_html($appointment->name); ?></td>
                        <td><?php echo esc_html($appointment->email); ?></td>
                        <td><?php echo esc_html($appointment->phone); ?></td>
                        <td><?php echo esc_html($appointment->service_name); ?></td>
                        <td><?php echo esc_html($appointment->appointment_date); ?></td>
                        <td><?php echo esc_html($appointment->appointment_time); ?></td>
                        <td>
                            <form method="post" style="display: inline;">
                                <select name="status" onchange="this.form.submit()">
                                    <option value="pending" <?php selected($appointment->status, 'pending'); ?>>Pending</option>
                                    <option value="confirmed" <?php selected($appointment->status, 'confirmed'); ?>>Confirmed</option>
                                    <option value="completed" <?php selected($appointment->status, 'completed'); ?>>Completed</option>
                                    <option value="cancelled" <?php selected($appointment->status, 'cancelled'); ?>>Cancelled</option>
                                </select>
                                <input type="hidden" name="appointment_id" value="<?php echo $appointment->id; ?>">
                                <input type="hidden" name="update_status" value="1">
                            </form>
                        </td>
                        <td>
                            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=appointment-bookings&delete=' . $appointment->id), 'delete_appointment'); ?>" 
                               onclick="return confirm('Are you sure you want to delete this appointment?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    public function services_page() {
        global $wpdb;
        
        // Handle service additions
        if (isset($_POST['add_service'])) {
            $wpdb->insert($this->services_table, array(
                'name' => sanitize_text_field($_POST['service_name']),
                'duration' => intval($_POST['duration']),
                'price' => floatval($_POST['price']),
                'description' => sanitize_textarea_field($_POST['description'])
            ));
            echo '<div class="notice notice-success"><p>Service added!</p></div>';
        }
        
        // Handle service deletions
        if (isset($_GET['delete_service']) && isset($_GET['_wpnonce'])) {
            if (wp_verify_nonce($_GET['_wpnonce'], 'delete_service')) {
                $wpdb->delete($this->services_table, array('id' => intval($_GET['delete_service'])));
                echo '<div class="notice notice-success"><p>Service deleted!</p></div>';
            }
        }
        
        $services = $wpdb->get_results("SELECT * FROM $this->services_table ORDER BY name");
        
        ?>
        <div class="wrap">
            <h1>Services</h1>
            
            <h2>Add New Service</h2>
            <form method="post">
                <table class="form-table">
                    <tr>
                        <th><label for="service_name">Service Name</label></th>
                        <td><input type="text" id="service_name" name="service_name" required></td>
                    </tr>
                    <tr>
                        <th><label for="duration">Duration (minutes)</label></th>
                        <td><input type="number" id="duration" name="duration" value="60" required></td>
                    </tr>
                    <tr>
                        <th><label for="price">Price</label></th>
                        <td><input type="number" id="price" name="price" step="0.01" value="0.00"></td>
                    </tr>
                    <tr>
                        <th><label for="description">Description</label></th>
                        <td><textarea id="description" name="description" rows="3"></textarea></td>
                    </tr>
                </table>
                <input type="submit" name="add_service" class="button-primary" value="Add Service">
            </form>
            
            <h2>Existing Services</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Duration</th>
                        <th>Price</th>
                        <th>Description</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($services as $service): ?>
                    <tr>
                        <td><?php echo esc_html($service->name); ?></td>
                        <td><?php echo esc_html($service->duration); ?> minutes</td>
                        <td>$<?php echo esc_html($service->price); ?></td>
                        <td><?php echo esc_html($service->description); ?></td>
                        <td>
                            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=appointment-services&delete_service=' . $service->id), 'delete_service'); ?>" 
                               onclick="return confirm('Are you sure you want to delete this service?')">Delete</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    public function booking_form_shortcode($atts) {
        global $wpdb;
        
        $services = $wpdb->get_results("SELECT * FROM $this->services_table WHERE is_active = 1 ORDER BY name");
        
        ob_start();
        ?>
        <div id="appointment-booking-form">
            <h3>Book an Appointment</h3>
            <form id="booking-form">
                <div class="form-group">
                    <label for="client-name">Full Name *</label>
                    <input type="text" id="client-name" name="name" required>
                </div>
                
                <div class="form-group">
                    <label for="client-email">Email *</label>
                    <input type="email" id="client-email" name="email" required>
                </div>
                
                <div class="form-group">
                    <label for="client-phone">Phone *</label>
                    <input type="tel" id="client-phone" name="phone" required>
                </div>
                
                <div class="form-group">
                    <label for="service">Service *</label>
                    <select id="service" name="service_id" required>
                        <option value="">Select a service</option>
                        <?php foreach ($services as $service): ?>
                        <option value="<?php echo $service->id; ?>" data-duration="<?php echo $service->duration; ?>">
                            <?php echo esc_html($service->name); ?> - $<?php echo esc_html($service->price); ?> (<?php echo $service->duration; ?> min)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="appointment-date">Preferred Date *</label>
                    <input type="text" id="appointment-date" name="date" required readonly>
                </div>
                
                <div class="form-group">
                    <label for="appointment-time">Preferred Time *</label>
                    <select id="appointment-time" name="time" required>
                        <option value="">Select a time</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="notes">Additional Notes</label>
                    <textarea id="notes" name="notes" rows="3"></textarea>
                </div>
                
                <button type="submit">Book Appointment</button>
            </form>
            
            <div id="booking-message" style="display: none;"></div>
        </div>
        
        <style>
        #appointment-booking-form {
            max-width: 600px;
            margin: 20px 0;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }
        #appointment-booking-form button {
            background: #0073aa;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        #appointment-booking-form button:hover {
            background: #005a87;
        }
        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 12px;
            border-radius: 4px;
            margin: 10px 0;
        }
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 12px;
            border-radius: 4px;
            margin: 10px 0;
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            // Initialize datepicker
            $('#appointment-date').datepicker({
                dateFormat: 'yy-mm-dd',
                minDate: 0,
                maxDate: '+3M'
            });
            
            // Load available times when date changes
            $('#appointment-date').change(function() {
                var date = $(this).val();
                var serviceId = $('#service').val();
                
                if (date && serviceId) {
                    loadAvailableTimes(date, serviceId);
                }
            });
            
            $('#service').change(function() {
                var date = $('#appointment-date').val();
                var serviceId = $(this).val();
                
                if (date && serviceId) {
                    loadAvailableTimes(date, serviceId);
                }
            });
            
            function loadAvailableTimes(date, serviceId) {
                $.ajax({
                    url: appointment_ajax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'get_available_slots',
                        date: date,
                        service_id: serviceId,
                        nonce: appointment_ajax.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            var timeSelect = $('#appointment-time');
                            timeSelect.empty().append('<option value="">Select a time</option>');
                            
                            $.each(response.data, function(index, time) {
                                timeSelect.append('<option value="' + time + '">' + time + '</option>');
                            });
                        }
                    }
                });
            }
            
            // Handle form submission
            $('#booking-form').submit(function(e) {
                e.preventDefault();
                
                var formData = {
                    action: 'book_appointment',
                    name: $('#client-name').val(),
                    email: $('#client-email').val(),
                    phone: $('#client-phone').val(),
                    service_id: $('#service').val(),
                    date: $('#appointment-date').val(),
                    time: $('#appointment-time').val(),
                    notes: $('#notes').val(),
                    nonce: appointment_ajax.nonce
                };
                
                $.ajax({
                    url: appointment_ajax.ajax_url,
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        var messageDiv = $('#booking-message');
                        
                        if (response.success) {
                            messageDiv.html('<div class="success-message">' + response.data + '</div>').show();
                            $('#booking-form')[0].reset();
                        } else {
                            messageDiv.html('<div class="error-message">' + response.data + '</div>').show();
                        }
                    }
                });
            });
        });
        </script>
        <?php
        return ob_get_clean();
    }
    
    public function get_available_slots() {
        if (!wp_verify_nonce($_POST['nonce'], 'appointment_nonce')) {
            wp_die('Security check failed');
        }
        
        $date = sanitize_text_field($_POST['date']);
        $service_id = intval($_POST['service_id']);
        
        global $wpdb;
        
        // Get service duration
        $service = $wpdb->get_row($wpdb->prepare("SELECT duration FROM $this->services_table WHERE id = %d", $service_id));
        $duration = $service ? $service->duration : 60;
        
        // Get existing appointments for the date
        $existing_appointments = $wpdb->get_results($wpdb->prepare(
            "SELECT appointment_time, s.duration FROM $this->table_name a 
             LEFT JOIN $this->services_table s ON a.service_id = s.id 
             WHERE appointment_date = %s AND status != 'cancelled'", 
            $date
        ));
        
        // Generate available time slots (9 AM to 5 PM)
        $available_slots = array();
        $start_hour = 9;
        $end_hour = 17;
        
        for ($hour = $start_hour; $hour < $end_hour; $hour++) {
            for ($minute = 0; $minute < 60; $minute += 30) {
                $time = sprintf('%02d:%02d:00', $hour, $minute);
                
                // Check if this slot conflicts with existing appointments
                $is_available = true;
                foreach ($existing_appointments as $appointment) {
                    $appointment_start = strtotime($appointment->appointment_time);
                    $appointment_end = $appointment_start + ($appointment->duration * 60);
                    $slot_start = strtotime($time);
                    $slot_end = $slot_start + ($duration * 60);
                    
                    if (($slot_start >= $appointment_start && $slot_start < $appointment_end) ||
                        ($slot_end > $appointment_start && $slot_end <= $appointment_end) ||
                        ($slot_start <= $appointment_start && $slot_end >= $appointment_end)) {
                        $is_available = false;
                        break;
                    }
                }
                
                if ($is_available) {
                    $available_slots[] = date('H:i', strtotime($time));
                }
            }
        }
        
        wp_send_json_success($available_slots);
    }
    
    public function handle_booking() {
        if (!wp_verify_nonce($_POST['nonce'], 'appointment_nonce')) {
            wp_send_json_error('Security check failed');
        }
        
        $name = sanitize_text_field($_POST['name']);
        $email = sanitize_email($_POST['email']);
        $phone = sanitize_text_field($_POST['phone']);
        $service_id = intval($_POST['service_id']);
        $date = sanitize_text_field($_POST['date']);
        $time = sanitize_text_field($_POST['time']);
        $notes = sanitize_textarea_field($_POST['notes']);
        
        // Validate required fields
        if (empty($name) || empty($email) || empty($phone) || empty($service_id) || empty($date) || empty($time)) {
            wp_send_json_error('Please fill in all required fields.');
        }
        
        global $wpdb;
        
        // Check if the slot is still available
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $this->table_name WHERE appointment_date = %s AND appointment_time = %s AND status != 'cancelled'",
            $date, $time . ':00'
        ));
        
        if ($existing > 0) {
            wp_send_json_error('This time slot is no longer available. Please select another time.');
        }
        
        // Insert the appointment
        $result = $wpdb->insert(
            $this->table_name,
            array(
                'name' => $name,
                'email' => $email,
                'phone' => $phone,
                'service_id' => $service_id,
                'appointment_date' => $date,
                'appointment_time' => $time . ':00',
                'notes' => $notes,
                'status' => 'pending'
            )
        );
        
        if ($result) {
            // Send confirmation email (optional)
            $this->send_confirmation_email($email, $name, $date, $time);
            wp_send_json_success('Your appointment has been booked successfully! You will receive a confirmation email shortly.');
        } else {
            wp_send_json_error('Failed to book appointment. Please try again.');
        }
    }
    
    private function send_confirmation_email($email, $name, $date, $time) {
        $subject = 'Appointment Confirmation';
        $message = "Hi $name,\n\n";
        $message .= "Your appointment has been booked for $date at $time.\n\n";
        $message .= "We will contact you soon to confirm the details.\n\n";
        $message .= "Thank you!";
        
        wp_mail($email, $subject, $message);
    }
    
    public function deactivate() {
        // Clean up if needed
    }
}

// Initialize the plugin
new AppointmentBookingSystem();
?>